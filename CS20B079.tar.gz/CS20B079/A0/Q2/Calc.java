import java.util.Stack;
public class Calc {
   
    public static void main(String [] args){
        String [] arr=Code.code;
        int i=0;
        Stack<Integer> S=new Stack<Integer>();
        int len=arr.length;
        while(i<len){
            if(arr[i].equals("push")){
                String temp=arr[i+1];
                int c=Integer.parseInt(temp);
                S.push(c);
                i=i+2;
            }
            else if(arr[i].equals("pop")){
                int c=S.pop();
                System.out.println(c);
                i++;
            }
            else if(arr[i].equals("dup")){
                int c=S.peek();
                S.push(c);
                i++;
            }
            else if(arr[i].equals("add")){
                if(S.size()>=2){
                    int c1=S.pop();
                    int c2=S.pop();
                    S.push(c1+c2);
                }
                i++;
            }
            else if(arr[i].equals("sub")){
                if(S.size()>=2){
                    int c1=S.pop();
                    int c2=S.pop();
                    S.push(c1-c2);
                }
                i++;
            }
            else if(arr[i].equals("mul")){
                if(S.size()>=2){
                    int c1=S.pop();
                    int c2=S.pop();
                    S.push(c1*c2);
                }
                i++;
            }
            else if(arr[i].equals("div")){
                if(S.size()>=2){
                    int c1=S.pop();
                    int c2=S.pop();
                    S.push(c1/c2);
                }
                i++;
            }
        }

        
    }
}
