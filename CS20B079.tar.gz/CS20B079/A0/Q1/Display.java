import java.util.Scanner;
public class Display{
    static void printer(char p,int r,int c,char x,int start,char [][] matrix){
        if(p=='a'){
            for(int i=0;i<r;i++){
                for(int j=start;j<start+c;j++){
                    if(i==0 && j>start && j<start+c-1){
                        matrix[i][j]=x;
                    }
                    else if(i==r/2){
                        matrix[i][j]=x;
                    }
                    else{
                        if((i!=0 && j==start) || (i!=0 && j==start+c-1)){
                            matrix[i][j]=x;
                        }
                    }
                }
            }
        }
        else if(p=='e'){
            for(int i=0;i<r;i++){
                for(int j=start;j<start+c;j++){
                    if(i==0 || i==r-1){
                        matrix[i][j]=x;
                    }
                    else if(i==(r-1)/2 && j<start+c-1){
                        matrix[i][j]=x;
                    }
                    else if(i!=(r-1)/2 && j==start){
                        matrix[i][j]=x;
                    }
                }
            }
        }
        else if(p=='i'){
            for(int i=0;i<r;i++){
                for(int j=start;j<start+c;j++){
                    if(i==0 || i==r-1){
                        matrix[i][j]=x;
                    }
                    else if(j==(2*start+c)/2){
                        matrix[i][j]=x;
                    }
                }
            }
        }
        else if(p=='o'){
            for(int i=0;i<r;i++){
                for(int j=start;j<start+c;j++){
                    if((i==0 && j>start && j<start+c-1) || (i==r-1 && j>start && j<start+c-1)){
                        matrix[i][j]=x;
                    }
                    else if((i!=0 && i!=r-1 && j==start) || (i!=0 && i!=r-1 && j==start+c-1)){
                        matrix[i][j]=x;
                    }
                }
            }
        }
        else if(p=='u'){
            for(int i=0;i<r;i++){
                for(int j=start;j<start+c;j++){
                    if(i==r-1 && j>start && j<start+c-1){
                        matrix[i][j]=x;
                    }
                    else if((i!=r-1 && j==start) || (i!=r-1 && j==start+c-1)){
                        matrix[i][j]=x;
                    }
                }
            }
        }
        else if(p=='c'){
            for(int i=0;i<r;i++){
                for(int j=start;j<start+c;j++){
                    if((i==0 && j>start)  || (i==r-1 && j>start)){
                        matrix[i][j]=x;
                    }
                    else if(i!=0 && i!=r-1 && j==start){
                        matrix[i][j]=x;
                    }
                }
            }
        }
        else if(p=='f'){
            for(int i=0;i<r;i++){
                for(int j=start;j<start+c;j++){
                    if(i==0){
                        matrix[i][j]=x;
                    }
                    else if(i==(r-1)/2 && j<start+c-1){
                        matrix[i][j]=x;
                    }
                    else if(i!=(r-1)/2 && j==start){
                        matrix[i][j]=x;
                    }
                }
            }
        }
        else if(p=='d'){
            for(int i=0;i<r;i++){
                for(int j=start;j<start+c;j++){
                    if((i==0 && j<start+c-1) || (i==r-1 && j<start+c-1)){
                        matrix[i][j]=x;
                    }
                    else if(j==start || (i!=0 && i!=r-1 && j==start+c-1)){
                        matrix[i][j]=x;
                    }
                }
            }
        }
        else if(p=='b'){
            for(int i=0;i<r;i++){
                for(int j=start;j<start+c;j++){
                    if(j<start+c-1 && (i==0 || i==r-1)){
                        matrix[i][j]=x;
                    }
                    else if(i==(r-1)/2 && j<start+c-1){
                        matrix[i][j]=x;
                    }
                    else if(i!=0 && i!=r-1 && i!=(r-1)/2 && (j==start || j==start+c-1)){
                        matrix[i][j]=x;
                    }
                }
            }
        }

    }
    static void traverse(String s,int r,int c,char x,char [][] matrix){
        int i=0;
        int len=s.length();
        int start=0;
        while(i<len){
            printer(s.charAt(i),r,c,x,start,matrix);
            start=start+c+1;
            i++;
        }
        int columns=c*s.length()+s.length()-1;
        for(int a=0;a<r;a++){
            for(int b=0;b<columns;b++){
                System.out.print(matrix[a][b]);
            }
            System.out.print("\n");
        }
    }
    public static void main(String[] args){
        int r=6,c=6;
        char x='#';
        int len =args.length;
        String names=args[len-1];
        int i=0;
        while(i<len){
            if(args[i].equals("-m")){
                String temp=args[i+1];
                c=Integer.parseInt(temp);
                i=i+2;
            }
            else if(args[i].equals("-n")){
                String temp=args[i+1];
                r=Integer.parseInt(temp);
                i=i+2;
            }
            else if(args[i].equals("-c")){
                x=args[i+1].charAt(0);
                i=i+2;
            }
            else{
                i++;
            }
        }
        int columns=c*names.length()+names.length()-1;
        char [][] matrix=new char [r][columns];
        for(int a=0;a<r;a++){
            for(int b=0;b<columns;b++){
                matrix[a][b]=' ';
            }
        }
        traverse(names,r,c,x,matrix);
    }

}